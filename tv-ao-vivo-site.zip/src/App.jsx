
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Play } from "lucide-react";
import videojs from "video.js";
import "video.js/dist/video-js.css";

const VideoPlayer = ({ options }) => {
  const videoRef = React.useRef(null);
  const playerRef = React.useRef(null);

  React.useEffect(() => {
    if (!playerRef.current) {
      playerRef.current = videojs(videoRef.current, options, () => {
        console.log("Player is ready");
      });
    } else {
      playerRef.current.src(options.sources);
    }
  }, [options]);

  return (
    <div data-vjs-player>
      <video ref={videoRef} className="video-js vjs-big-play-centered" />
    </div>
  );
};

export default function LiveTV() {
  const videoJsOptions = {
    autoplay: true,
    controls: true,
    responsive: true,
    fluid: true,
    sources: [
      {
        src: "https://canalnoventasdesebhia.mystrikingly.com/live/stream.m3u8",
        type: "application/x-mpegURL",
      },
    ],
  };

  return (
    <main className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-5xl shadow-2xl">
        <CardContent className="p-0">
          <div className="bg-zinc-900 text-white px-4 py-2 flex items-center justify-between">
            <h1 className="text-xl font-bold">📺 Canal Ao Vivo</h1>
            <Badge variant="outline" className="text-green-500 border-green-500">
              <Play className="w-4 h-4 mr-1" /> Ao Vivo 24h
            </Badge>
          </div>
          <VideoPlayer options={videoJsOptions} />
        </CardContent>
      </Card>
    </main>
  );
}
